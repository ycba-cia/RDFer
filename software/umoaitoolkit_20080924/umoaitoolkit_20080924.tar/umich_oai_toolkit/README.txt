
Documentation for the UMich OAI toolkit can be found here:

  http://webservices.itcs.umich.edu/mediawiki/dlxs14/index.php/Ancillary_Resources

